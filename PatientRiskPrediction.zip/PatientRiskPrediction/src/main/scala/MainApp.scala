import org.apache.spark.sql.SparkSession
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.DataFrame

object MainApp {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("PatientRiskPrediction")
      .master("local[*]")
      .getOrCreate()

    // Step 1: Load CSV
    val rawDF = DataLoader.loadCSV(spark, "src/main/resources/patient_risk_dataset_2.csv")

    // Step 2: Feature Engineering
    val processedDF = FeatureEngineering.transform(rawDF)

    // Step 3: Assemble features
    val assembler = new VectorAssembler()
      .setInputCols(Array("Age", "SeverityScore", "HospitalStayDays", "ICUStayDays"))
      .setOutputCol("features")

    val assembledDF: DataFrame = assembler.transform(processedDF)

    // Step 4: Train model
    val model = RiskModel.train(assembledDF)

    // Step 5: Predict
    val predictions = model.transform(assembledDF)

    // Step 6: Show predictions in terminal
    predictions.select("PatientID", "Age", "SeverityScore", "HospitalStayDays", "ICUStayDays", "label", "prediction")
      .show(truncate = false)

    spark.stop()
  }
}
