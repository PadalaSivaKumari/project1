import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.sql.DataFrame
import org.apache.spark.ml.classification.LogisticRegressionModel

object RiskModel {
  def train(df: DataFrame): LogisticRegressionModel = {
    val trainingData = df.select("features", "label")

    val lr = new LogisticRegression()
    lr.fit(trainingData)
  }
}
