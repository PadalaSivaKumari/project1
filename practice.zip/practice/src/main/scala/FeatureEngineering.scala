import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

object FeatureEngineering {
  def transform(df: DataFrame): DataFrame = {
    df.withColumn("age_group", when(col("Age") < 30, "young")
        .when(col("Age") < 60, "middle-aged")
        .otherwise("senior"))
      .withColumn("label", when(col("HospitalDeath") === "Yes", 1).otherwise(0))
      .na.fill(0)
  }
}
