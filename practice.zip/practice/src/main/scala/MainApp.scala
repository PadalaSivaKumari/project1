import org.apache.spark.sql.SparkSession

object MainApp {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("practice[PatientRiskPrediction]")
      .master("local[*]")
      .getOrCreate()

    val rawDF = DataLoader.loadCSV(spark, "src/main/resources/patient_risk_dataset.csv")
    //val rawDF = DataLoader.loadCSV(spark, "src/main/resources/patient_risk_dataset 1.csv")

    val processedDF = FeatureEngineering.transform(rawDF)
    val model = RiskModel.train(processedDF)
    val predictions = model.transform(processedDF)

    PredictionSaver.save(predictions, "output/predictions")
    spark.stop()
  }
}
