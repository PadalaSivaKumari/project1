import org.apache.spark.sql.DataFrame

object PredictionSaver {
  def save(df: DataFrame, path: String): Unit = {
//    df.write
//      .option("header", "true")
//      .mode("overwrite")
//      .csv(path)
    df.write
      .option("header", "true")
      .mode("overwrite")
      .csv(path)
  }
}
