import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.DataFrame
import org.apache.spark.ml.classification.LogisticRegressionModel

object RiskModel {
  def train(df: DataFrame): LogisticRegressionModel = {
    val assembler = new VectorAssembler()
      .setInputCols(Array("Age", "SeverityScore", "HospitalStayDays", "ICUStayDays"))
      .setOutputCol("features")

    val trainingData = assembler.transform(df).select("features", "label")

    val lr = new LogisticRegression()
    lr.fit(trainingData)
  }
}
