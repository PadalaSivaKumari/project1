object p1 {
  def main(args: Array[String]): Unit = {
    print("hi")
  }

}
